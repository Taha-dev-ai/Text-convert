import {a,b,c} from './module2.mjs'
// console.log(mname);
console.log(a,b,c);
// console.log(b);
// console.log(c);