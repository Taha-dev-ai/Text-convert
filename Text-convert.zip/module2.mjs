const a = "taha";
const b = "hannan";
const c = "haris";
const d = "tayyab";

export {a,b,c}
// export {b}
// export {c}