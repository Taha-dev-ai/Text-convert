import './App.css';
import Navbar from './components/Navbar';
import About from './components/About';
import React, { useState } from 'react';
// import Alert from './Alert';
import Home from './components/TextForm';
import { 
  Routes,
  Route,
  // Link
}  from 'react-router-dom'

function App() {
  const [mode,setMode] = useState('light')
  const toggleMode=()=>{
    if (mode === 'light') {
      setMode('dark')
    }
    else {
      setMode('light')
    }
  }
  return (
    <>
      <Routes>
         <Route path='/' element={
              <>
                  <Navbar title = "Textutil" mode={mode} toggleMode={toggleMode}/>
                  {/* <Alert Alert="This is Alert"/> */}
                  <Home/>
              </>
                  }>
          </Route>
          <Route path="/about" element={
              <>
                  <Navbar title = "Textutil" mode={mode} toggleMode={toggleMode}/>
                  {/* <Alert Alert="This is Alert"/> */}
                  <About/>
              </>
              }>  
          </Route> 
          {/* <Route path="/about" element={<> <Navbar title = "Textutil" mode={mode} toggleMode={toggleMode}/> <About/></>}>  </Route>       */}
      </Routes>   
    </>
  );
}    
export default App;

